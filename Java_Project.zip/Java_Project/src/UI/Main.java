package UI;

import javax.swing.UIManager;
public class Main {
	public static void main(String[] args) {
		new Frame();
	}
}

// Total lines of code is around : 3500