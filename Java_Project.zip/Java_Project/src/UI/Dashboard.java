package UI;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.net.URL;

public class Dashboard extends JPanel {

    JLabel lbHeading;
    JLabel imageLabel; // JLabel to display the image
    JPanel headingPanel;
    Frame parentFrame;

    Dashboard(Frame parentFrame) {
        this.parentFrame = parentFrame;
        this.setLayout(new BorderLayout());

        // Create a dash board
        lbHeading = new JLabel("Welcome to Medical Store Management System");
        lbHeading.setFont(new Font("cambria", Font.BOLD, 30));
        lbHeading.setBorder(new EmptyBorder(new Insets(40, 0, 20, 0)));
        JPanel temp = new JPanel();
        temp.add(lbHeading);

        // Load and display the image
        try {
            URL imageURL = new URL("https://uploads-ssl.webflow.com/60edc0a8835d5b38bf11f03f/6336e2dd9af9104c4019869e_medical-inventory.jpg");
            Image image = ImageIO.read(imageURL);
            imageLabel = new JLabel(new ImageIcon(image));
            this.add(imageLabel, BorderLayout.CENTER);
        } catch (IOException e) {
            e.printStackTrace();
        }

        headingPanel = new JPanel(new BorderLayout());
        headingPanel.add(temp, BorderLayout.NORTH); // Place the heading at the top
        this.add(headingPanel, BorderLayout.NORTH); // Place the image below the heading
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new Dashboard((Frame) frame));
        frame.pack();
        frame.setVisible(true);
    }
}
