package UI;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class ExpiryMedicineList extends JPanel {
    JTable jtTable;
    JPanel tablePanel;

    Frame parentFrame;
    JButton btnHideMedicine, btnHideSupplier;
    Box medicineLayout, supplierLayout;
    Object[][] data;

    JButton btnSave;

    public ExpiryMedicineList(Frame parentFrame, boolean isReferenced, Object[][] data) {
        this.parentFrame = parentFrame;
        this.setLayout(new BorderLayout());

        if (isReferenced) {
            this.data = data;
        } else {
            this.data = getExpiringMedicinesFromDatabase();
        }
        initUI(isReferenced, this.data);
    }

    private Object[][] getExpiringMedicinesFromDatabase() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<Object[]> medicinesList = new ArrayList<>();

        try {
            // Establish your database connection here...
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/medicine", "username", "password");

            // Get the current date
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date currentDate = new Date();
            String formattedCurrentDate = dateFormat.format(currentDate);
            
            // Query to retrieve medicines with expiry dates less than the current date
            String query = "SELECT MedicineID, Name, Quantity, SupplierID, Expiry_Date FROM Medicines WHERE Expiry_Date < ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, formattedCurrentDate);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int medicineID = resultSet.getInt("MedicineID");
                String name = resultSet.getString("Name");
                int quantity = resultSet.getInt("Quantity");
                int supplierID = resultSet.getInt("SupplierID");
                String expiryDate = resultSet.getString("Expiry_Date");

                Object[] medicineInfo = {String.valueOf(medicineID), name, String.valueOf(quantity), String.valueOf(supplierID), expiryDate};
                medicinesList.add(medicineInfo);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately...
        } finally {
            // Close database resources (resultSet, preparedStatement, connection) here...
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Convert the list to a 2D array
        Object[][] medicinesArray = new Object[medicinesList.size()][];
        medicinesList.toArray(medicinesArray);

        return medicinesArray;
    }

    private void initUI(boolean isReferenced, Object[][] data) {
        Object[] columns = {"Medicine ID", "Name", "Quantity", "Supplier ID", "Expiry Date"};
        if (data.length == 0) {
            JOptionPane.showMessageDialog(getRootPane(), "No medicine found!");
            return;
        }

        tablePanel = new JPanel(new BorderLayout());
        jtTable = new JTable(data, columns);
        jtTable.setFont(new Font("cambria", Font.PLAIN, 15));
        jtTable.setRowHeight(18);

        jtTable.setModel(new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });

        if (!isReferenced) {
            jtTable.setCellSelectionEnabled(true);
            ListSelectionModel select = jtTable.getSelectionModel();
            select.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            select.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    int[] row = jtTable.getSelectedRows();
                    int[] column = jtTable.getSelectedColumns();

                    if (row.length == 1 && column.length == 1) {
                        if (column[0] == 0) {
                            displayMedicineInfo(row[0], column[0]);
                        }
                        if (column[0] == 3) {
                            displaySupplierInfo(row[0], column[0]);
                        }
                    }
                }
            });
        }

        JScrollPane sp = new JScrollPane(jtTable);
        tablePanel.add(sp, BorderLayout.CENTER);
        tablePanel.setMaximumSize(new Dimension(400, -1));
        this.add(tablePanel, BorderLayout.CENTER);

        btnSave = new JButton("Save as csv");
        btnSave.setFont(new Font("cambria", Font.PLAIN, 16));
        btnSave.setBorder(new EmptyBorder(new Insets(10, 20, 10, 20)));
        btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));
        this.add(new JPanel().add(btnSave), BorderLayout.SOUTH);
        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Save medicine list");

                int fileSelected = fileChooser.showSaveDialog(null);
                if (fileSelected == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    String filePath = fileToSave.getAbsolutePath();
                    filePath += ".csv";
                    // Add code to save the CSV file here...
                    // You may use a library like OpenCSV to simplify CSV handling
                }
            }
        });
    }

    private void displayMedicineInfo(int row, int col) {
        if (medicineLayout != null) {
            this.remove(medicineLayout);
            medicineLayout.removeAll();
            medicineLayout.validate();
            medicineLayout.revalidate();
        }

        medicineLayout = Box.createVerticalBox();
        JLabel headingLabel = new JLabel("Medicine information");
        headingLabel.setFont(new Font("cambria", Font.PLAIN, 25));
        medicineLayout.add(new JPanel().add(headingLabel));
        // Add code to display medicine information here...

        btnHideMedicine = new JButton("Hide");
        btnHideMedicine.setFont(new Font("cambria", Font.PLAIN, 16));
        btnHideMedicine.setBorder(new EmptyBorder(new Insets(5, 10, 5, 10)));

        btnHideMedicine.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                removeLayout();
            }
        });
        medicineLayout.add(btnHideMedicine);
        this.add(medicineLayout, BorderLayout.WEST);
        this.validate();
        this.revalidate();
        parentFrame.refreshDisplay();
    }

    private void removeLayout() {
        this.remove(medicineLayout);
        this.validate();
        this.revalidate();
        parentFrame.refreshDisplay();
    }

    private void displaySupplierInfo(int row, int col) {
        if (supplierLayout != null) {
            this.remove(supplierLayout);
            supplierLayout.removeAll();
            supplierLayout.validate();
            supplierLayout.revalidate();
        }

        supplierLayout = Box.createVerticalBox();
        JLabel headingLabel = new JLabel("Supplier information");
        headingLabel.setFont(new Font("cambria", Font.PLAIN, 25));
        supplierLayout.add(new JPanel().add(headingLabel));
        // Add code to display supplier information here...

        btnHideSupplier = new JButton("Hide");
        btnHideSupplier.setFont(new Font("cambria", Font.PLAIN, 16));
        btnHideSupplier.setBorder(new EmptyBorder(new Insets(5, 10, 5, 10)));

        btnHideSupplier.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                removeSupplierLayout();
            }
        });

        supplierLayout.add(btnHideSupplier);
        this.add(supplierLayout, BorderLayout.EAST);
        this.validate();
        this.revalidate();
        parentFrame.refreshDisplay();
    }

    private void removeSupplierLayout() {
        this.remove(supplierLayout);
        this.validate();
        this.revalidate();
        parentFrame.refreshDisplay();
    }
}
